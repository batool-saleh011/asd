import { Router } from "express";
import * as communityscntroller from './communities.control.js';
import fileUpload, { fileValidation } from "../../services/multer.js";
const router = Router();
router.post("/createCommunitys", fileUpload(fileValidation.image).fields([
{name:'mainImage',maxCount:1},
{name:'supImages',maxCount:30},

]),communityscntroller.createCommunitys);
export default router;